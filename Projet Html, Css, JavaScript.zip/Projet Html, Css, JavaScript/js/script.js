function calculerMontants() {
  let lignes = document.querySelectorAll('#table-body tr');
  let totalHT = 0;

  lignes.forEach((ligne) => {
    let prix = parseFloat(ligne.querySelector('.prix').value) || 0;
    let quantite = parseFloat(ligne.querySelector('.quantite').value) || 0;
    let montant = prix * quantite;
    ligne.querySelector('.montant').textContent = montant.toFixed(2) + ' €';
    totalHT += montant;
  });

  document.getElementById('total-ht').textContent = totalHT.toFixed(2) + ' €';
  let tva = totalHT * 0.18;
  document.getElementById('tva').textContent = tva.toFixed(2) + ' €';
  document.getElementById('total-ttc').textContent = (totalHT + tva).toFixed(2) + ' €';
}

// Calcul automatique dès qu’on modifie prix ou quantité
document.querySelectorAll('.prix, .quantite').forEach(input => {
  input.addEventListener('input', calculerMontants);
});

function imprimer() {
  window.print();
}

function resetForm() {
  if (confirm("Réinitialiser tous les champs ?")) {
    localStorage.removeItem('factureData');
    location.reload();
  }
}

function sauvegarder() {
  const data = document.querySelectorAll('input, textarea');
  let formData = {};
  data.forEach(input => {
    formData[input.name || input.placeholder || input.type] = input.value;
  });
  localStorage.setItem('factureData', JSON.stringify(formData));
  alert("Données enregistrées dans le navigateur !");
}

function charger() {
  const saved = localStorage.getItem('factureData');
  if (!saved) return alert("Aucune donnée enregistrée !");
  const formData = JSON.parse(saved);
  const data = document.querySelectorAll('input, textarea');
  data.forEach(input => {
    let key = input.name || input.placeholder || input.type;
    if (formData[key] !== undefined) {
      input.value = formData[key];
    }
  });
  calculerMontants();
}
